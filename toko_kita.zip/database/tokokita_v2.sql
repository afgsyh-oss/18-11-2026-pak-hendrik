CREATE DATABASE IF NOT EXISTS tokokita_v2 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tokokita_v2;

CREATE TABLE IF NOT EXISTS users (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 nama VARCHAR(100) NOT NULL,
 role ENUM('admin','kasir','customer') NOT NULL DEFAULT 'kasir',
 customer_id INT UNSIGNED NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nama VARCHAR(100) NOT NULL UNIQUE,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 barcode VARCHAR(50) NULL UNIQUE,
 sku VARCHAR(40) NULL UNIQUE,
 nama VARCHAR(150) NOT NULL,
 category_id INT UNSIGNED NULL,
 harga_beli DECIMAL(12,2) NOT NULL DEFAULT 0,
 harga_jual DECIMAL(12,2) NOT NULL DEFAULT 0,
 stok INT NOT NULL DEFAULT 0,
 satuan VARCHAR(20) NOT NULL DEFAULT 'pcs',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_products_category FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL,
 INDEX idx_products_nama(nama)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS customers (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nama VARCHAR(120) NOT NULL,
 telepon VARCHAR(30) NULL,
 alamat TEXT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

ALTER TABLE users ADD CONSTRAINT fk_users_customer FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS sales (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 invoice VARCHAR(40) NOT NULL UNIQUE,
 customer_id INT UNSIGNED NULL,
 user_id INT UNSIGNED NULL,
 order_user_id INT UNSIGNED NULL,
 order_type ENUM('pickup','delivery') NULL,
 delivery_address TEXT NULL,
 order_status ENUM('menunggu_pembayaran','menunggu_verifikasi','diproses','siap_diambil','dalam_pengiriman','selesai','ditolak') NULL,
 payment_status ENUM('belum_bayar','menunggu_verifikasi','terverifikasi','ditolak') NULL,
 payment_proof VARCHAR(255) NULL,
 tanggal DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 subtotal DECIMAL(12,2) NOT NULL,
 diskon DECIMAL(12,2) NOT NULL DEFAULT 0,
 total DECIMAL(12,2) NOT NULL,
 metode_bayar ENUM('Tunai','QRIS','Transfer','Debit') NOT NULL DEFAULT 'Tunai',
 bayar DECIMAL(12,2) NOT NULL,
 kembalian DECIMAL(12,2) NOT NULL DEFAULT 0,
 catatan VARCHAR(255) NULL,
 CONSTRAINT fk_sales_customer FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE SET NULL,
 CONSTRAINT fk_sales_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
 CONSTRAINT fk_sales_order_user FOREIGN KEY(order_user_id) REFERENCES users(id) ON DELETE SET NULL,
 INDEX idx_sales_tanggal(tanggal)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sale_items (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 sale_id BIGINT UNSIGNED NOT NULL,
 product_id INT UNSIGNED NULL,
 nama_produk VARCHAR(150) NOT NULL,
 barcode VARCHAR(50) NULL,
 harga DECIMAL(12,2) NOT NULL,
 qty INT NOT NULL,
 diskon DECIMAL(12,2) NOT NULL DEFAULT 0,
 total DECIMAL(12,2) NOT NULL,
 CONSTRAINT fk_items_sale FOREIGN KEY(sale_id) REFERENCES sales(id) ON DELETE CASCADE,
 CONSTRAINT fk_items_product FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO categories(nama) VALUES
('Makanan'),('Minuman'),('Kebutuhan Rumah'),('Perawatan'),('Lainnya');

INSERT IGNORE INTO products(barcode,sku,nama,category_id,harga_beli,harga_jual,stok,satuan)
SELECT '8991001000001','PRD001','Air Mineral 600ml',id,2500,4000,50,'pcs' FROM categories WHERE nama='Minuman';
INSERT IGNORE INTO products(barcode,sku,nama,category_id,harga_beli,harga_jual,stok,satuan)
SELECT '8991001000002','PRD002','Teh Pucuk 350ml',id,3500,5000,40,'pcs' FROM categories WHERE nama='Minuman';
INSERT IGNORE INTO products(barcode,sku,nama,category_id,harga_beli,harga_jual,stok,satuan)
SELECT '8991001000003','PRD003','Kopi Good Day',id,1300,2000,60,'pcs' FROM categories WHERE nama='Minuman';
INSERT IGNORE INTO products(barcode,sku,nama,category_id,harga_beli,harga_jual,stok,satuan)
SELECT '8991001000004','PRD004','Indomie Goreng',id,2700,3500,100,'pcs' FROM categories WHERE nama='Makanan';
INSERT IGNORE INTO products(barcode,sku,nama,category_id,harga_beli,harga_jual,stok,satuan)
SELECT '8991001000005','PRD005','Mie Sedaap Ayam Bawang',id,2400,3000,80,'pcs' FROM categories WHERE nama='Makanan';
INSERT IGNORE INTO products(barcode,sku,nama,category_id,harga_beli,harga_jual,stok,satuan)
SELECT '8991001000006','PRD006','Roti Cokelat',id,5000,7000,25,'pcs' FROM categories WHERE nama='Makanan';
INSERT IGNORE INTO products(barcode,sku,nama,category_id,harga_beli,harga_jual,stok,satuan)
SELECT '8991001000007','PRD007','Biskuit Kelapa',id,6000,8500,30,'pcs' FROM categories WHERE nama='Makanan';
INSERT IGNORE INTO products(barcode,sku,nama,category_id,harga_beli,harga_jual,stok,satuan)
SELECT '8991001000008','PRD008','Sabun Mandi',id,2800,4000,35,'pcs' FROM categories WHERE nama='Perawatan';
INSERT IGNORE INTO products(barcode,sku,nama,category_id,harga_beli,harga_jual,stok,satuan)
SELECT '8991001000009','PRD009','Sampo Sachet',id,900,1500,50,'pcs' FROM categories WHERE nama='Perawatan';
INSERT IGNORE INTO products(barcode,sku,nama,category_id,harga_beli,harga_jual,stok,satuan)
SELECT '8991001000010','PRD010','Sabun Cuci Piring',id,4300,6000,20,'pcs' FROM categories WHERE nama='Kebutuhan Rumah';
