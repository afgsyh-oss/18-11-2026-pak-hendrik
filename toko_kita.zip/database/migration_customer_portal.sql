-- Jalankan SATU KALI pada database tokokita_v2 yang sudah berisi data.
USE tokokita_v2;

ALTER TABLE users
  MODIFY role ENUM('admin','kasir','customer') NOT NULL DEFAULT 'kasir',
  ADD COLUMN customer_id INT UNSIGNED NULL AFTER role;

ALTER TABLE users
  ADD CONSTRAINT fk_users_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL;

ALTER TABLE sales
  ADD COLUMN order_user_id INT UNSIGNED NULL AFTER user_id,
  ADD COLUMN order_type ENUM('pickup','delivery') NULL AFTER order_user_id,
  ADD COLUMN delivery_address TEXT NULL AFTER order_type,
  ADD COLUMN order_status ENUM('menunggu_pembayaran','menunggu_verifikasi','diproses','siap_diambil','dalam_pengiriman','selesai','ditolak') NULL AFTER delivery_address,
  ADD COLUMN payment_status ENUM('belum_bayar','menunggu_verifikasi','terverifikasi','ditolak') NULL AFTER order_status,
  ADD COLUMN payment_proof VARCHAR(255) NULL AFTER payment_status,
  ADD CONSTRAINT fk_sales_order_user FOREIGN KEY (order_user_id) REFERENCES users(id) ON DELETE SET NULL;
