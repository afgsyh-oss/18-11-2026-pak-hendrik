<?php
require __DIR__.'/config/database.php';
require __DIR__.'/includes/functions.php';
if (!empty($_SESSION['user'])) redirect(($_SESSION['user']['role'] ?? '') === 'customer' ? 'user/index.php' : 'index.php');
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $nama=trim($_POST['nama']??''); $username=trim($_POST['username']??'');
    $telepon=trim($_POST['telepon']??''); $alamat=trim($_POST['alamat']??'');
    $password=$_POST['password']??''; $confirm=$_POST['password_confirmation']??'';
    if ($nama==='' || $username==='' || $password==='') $error='Nama, username, dan password wajib diisi.';
    elseif (!preg_match('/^[A-Za-z0-9_.-]{4,50}$/',$username)) $error='Username minimal 4 karakter dan hanya boleh berisi huruf, angka, titik, garis, atau strip.';
    elseif (strlen($password)<8) $error='Password minimal 8 karakter.';
    elseif ($password!==$confirm) $error='Konfirmasi password tidak sama.';
    else {
        try {
            $pdo->beginTransaction();
            $st=$pdo->prepare('INSERT INTO customers(nama,telepon,alamat) VALUES(?,?,?)');
            $st->execute([$nama,$telepon?:null,$alamat?:null]); $customerId=(int)$pdo->lastInsertId();
            $st=$pdo->prepare("INSERT INTO users(username,password,nama,role,customer_id) VALUES(?,?,?,'customer',?)");
            $st->execute([$username,password_hash($password,PASSWORD_DEFAULT),$nama,$customerId]);
            $userId=(int)$pdo->lastInsertId(); $pdo->commit();
            session_regenerate_id(true); $_SESSION['user']=['id'=>$userId,'nama'=>$nama,'role'=>'customer','customer_id'=>$customerId];
            redirect('user/index.php');
        } catch(Throwable $e) { if($pdo->inTransaction())$pdo->rollBack(); $error='Username sudah digunakan atau pendaftaran gagal. Coba username lain.'; }
    }
}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Daftar Pelanggan - TOKOKITA</title><link rel="stylesheet" href="assets/css/app.css"></head><body style="display:grid;place-items:center;min-height:100vh;padding:20px"><form method="post" class="card" style="width:min(480px,100%);padding:28px"><div class="brand" style="padding:0 0 20px;color:#173b32"><span class="brand-mark">T</span><div><b>TOKOKITA</b><small style="color:#829088">AKUN PELANGGAN</small></div></div><h2>Buat akun pelanggan</h2><p class="sub">Daftar untuk mulai berbelanja.</p><?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><div class="field"><label>Nama lengkap *</label><input class="form-control" name="nama" required value="<?=e($_POST['nama']??'')?>"></div><div class="field"><label>Username *</label><input class="form-control" name="username" required minlength="4" value="<?=e($_POST['username']??'')?>"></div><div class="field"><label>Nomor telepon</label><input class="form-control" name="telepon" value="<?=e($_POST['telepon']??'')?>"></div><div class="field"><label>Alamat</label><textarea class="form-control" name="alamat" rows="2"><?=e($_POST['alamat']??'')?></textarea></div><div class="field"><label>Password (minimal 8 karakter) *</label><input class="form-control" type="password" name="password" minlength="8" required></div><div class="field"><label>Ulangi password *</label><input class="form-control" type="password" name="password_confirmation" minlength="8" required></div><button class="btn" style="width:100%">Daftar</button><p class="muted-text" style="font-size:12px;margin-top:16px">Sudah punya akun? <a href="login.php">Login</a></p></form></body></html>
