<?php
require __DIR__.'/../config/database.php'; require __DIR__.'/../includes/functions.php'; require_customer();
$pageTitle='Beranda'; $products=$pdo->query('SELECT id,nama,harga_jual,stok,satuan FROM products WHERE stok>0 ORDER BY created_at DESC LIMIT 8')->fetchAll();
require __DIR__.'/_header.php'; ?>
<div class="page-head"><div><h1>Selamat datang, <?=e($_SESSION['user']['nama'])?>!</h1><p class="sub">Temukan kebutuhanmu dan belanja dengan mudah.</p></div><a class="btn" href="katalog.php">Lihat semua produk</a></div>
<div class="card" style="margin-bottom:18px"><h2 style="margin-top:0">Belanja lebih mudah di TOKOKITA</h2><p class="sub">Pilih produk, checkout, lalu ambil sendiri di toko atau gunakan layanan antar jika tersedia.</p></div>
<h2 style="font-size:18px">Produk tersedia</h2><div class="shop-grid"><?php foreach($products as $p):?><article class="shop-product"><small>Stok tersedia: <?= (int)$p['stok']?> <?=e($p['satuan'])?></small><h3><?=e($p['nama'])?></h3><div class="price"><?=rupiah($p['harga_jual'])?></div><form method="post" action="keranjang.php" style="margin-top:12px"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="add"><input type="hidden" name="product_id" value="<?=$p['id']?>"><input type="hidden" name="qty" value="1"><button class="btn btn-sm">＋ Keranjang</button></form></article><?php endforeach;?><?php if(!$products):?><div class="card">Belum ada produk tersedia.</div><?php endif;?></div>
<?php require __DIR__.'/_footer.php'; ?>
