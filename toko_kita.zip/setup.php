<?php
require __DIR__.'/config/database.php';
require __DIR__.'/includes/functions.php';
$count=(int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
if($count===0){
 $hash=password_hash('admin12345',PASSWORD_DEFAULT);
 $st=$pdo->prepare("INSERT INTO users(username,password,nama,role) VALUES(?,?,?,'admin')");
 $st->execute(['admin',$hash,'Administrator']);
}
?> 
<!doctype html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width">
        <title>Setup TOKOKITA</title>
    </head>
    <body style="font:16px Arial;max-width:650px;margin:60px auto;padding:20px">
        <h1>TOKOKITA berhasil disiapkan</h1>
        <p>Database terhubung. Akun admin awal: <b>admin</b> / <b>admin12345</b>.</p>
        <p>Silakan login, lalu hapus file <code>setup.php</code> demi keamanan.</p>
        <a href="login.php">Buka halaman login</a>
    </body>
</html>