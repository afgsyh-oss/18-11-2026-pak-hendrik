(() => {
    const $ = s => document.querySelector(s);
    const cart = new Map();
    const money = n => 'Rp' + Number(n || 0).toLocaleString('id-ID');
    let total = 0;

    const products = window.TOKOKITA_PRODUCTS || [];
    const paymentConfig = window.TOKOKITA_PAYMENT || {};

    function calc() {
        let sub = 0;
        cart.forEach(x => sub += x.harga * x.qty);

        const disc = Math.min(sub, Math.max(0, Number($('#discount').value) || 0));
        total = sub - disc;

        $('#subtotal').textContent = money(sub);
        $('#discountLabel').textContent = money(disc);
        $('#grandTotal').textContent = money(total);
        $('#checkoutBtn').disabled = !cart.size;

        const wrap = $('#cartItems');
        if (!cart.size) {
            wrap.innerHTML = '<div class="empty">Belum ada produk dipilih.</div>';
            return;
        }

        wrap.innerHTML = '';
        cart.forEach(x => {
            const row = document.createElement('div');
            row.className = 'cart-row';
            row.innerHTML = `<div><b>${esc(x.nama)}</b><div class="muted-text">${money(x.harga)} × ${x.qty} = <b>${money(x.harga * x.qty)}</b></div></div><div class="qty"><button data-dec="${x.id}">−</button><span>${x.qty}</span><button data-inc="${x.id}">+</button></div>`;
            wrap.append(row);
        });
    }

    function esc(s) {
        return String(s).replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));
    }

    function add(p) {
        const old = cart.get(String(p.id));
        if (old) {
            if (old.qty >= Number(p.stok)) return alert('Jumlah melebihi stok.');
            old.qty++;
        } else {
            cart.set(String(p.id), {
                id: Number(p.id),
                nama: p.nama,
                harga: Number(p.harga_jual ?? p.harga),
                qty: 1,
                stok: Number(p.stok)
            });
        }
        calc();
    }

    function updatePaymentUI() {
        const method = $('#method').value;
        const guide = $('#paymentGuide');
        const paidField = $('#paidField');
        const paid = $('#paid');
        const refField = $('#referenceField');
        const confirmField = $('#confirmationField');
        const confirm = $('#paymentConfirmed');
        const resultLabel = $('#paymentResultLabel');

        $('#paymentError').style.display = 'none';
        $('#paymentReference').value = '';
        confirm.checked = false;

        if (method === 'Tunai') {
            guide.innerHTML = '<strong>Pembayaran tunai</strong>Masukkan uang yang diberikan pelanggan. Sistem menghitung kembalian secara otomatis.';
            paidField.hidden = false;
            paid.required = true;
            refField.hidden = true;
            confirmField.hidden = true;
            resultLabel.textContent = 'Kembalian';
            paid.value = total;
            updateChange();
            paid.focus();
            return;
        }

        paidField.hidden = true;
        paid.required = false;
        paid.value = total;
        refField.hidden = method === 'QRIS';
        confirmField.hidden = false;
        resultLabel.textContent = 'Total dibayar';
        $('#change').textContent = money(total);

        if (method === 'QRIS') {
            const imgPath = paymentConfig.qrisImage || '';
            const safePath = /^assets\/img\/[a-zA-Z0-9_.-]+$/.test(imgPath) ? imgPath : '';
            const imageHtml = safePath
                ? `<img src="${esc(safePath)}" alt="QRIS toko" onerror="this.style.display='none'">`
                : '';
            guide.innerHTML = `<strong>Pembayaran QRIS</strong>${imageHtml}<div>Pastikan pelanggan memindai QRIS milik toko dan pembayaran sudah masuk ke aplikasi/akun merchant.</div><div class="payment-amount">${money(total)}</div><div class="muted">Nominal transaksi otomatis mengikuti total belanja.</div>`;
            $('#referenceLabel').textContent = 'ID transaksi QRIS (opsional)';
            $('#paymentReference').placeholder = 'Masukkan ID transaksi QRIS jika tersedia';
        } else if (method === 'Transfer') {
            const bank = paymentConfig.bankName || '';
            const account = paymentConfig.bankAccount || '';
            const holder = paymentConfig.bankHolder || '';
            const accountInfo = bank && account && holder
                ? `<div><b>${esc(bank)}</b><br>No. rekening: <b>${esc(account)}</b><br>Atas nama: <b>${esc(holder)}</b></div>`
                : '<div class="muted">Informasi rekening belum diatur. Isi konfigurasi rekening toko di bagian atas kasir.php.</div>';
            guide.innerHTML = `<strong>Transfer bank</strong>${accountInfo}<div class="payment-amount">${money(total)}</div><div class="muted">Periksa mutasi/rekening toko sebelum mengonfirmasi pembayaran.</div>`;
            refField.hidden = false;
            $('#referenceLabel').textContent = 'Nomor referensi transfer (opsional)';
            $('#paymentReference').placeholder = 'Nomor referensi dari bukti transfer';
        } else {
            guide.innerHTML = `<strong>Pembayaran kartu debit</strong>Masukkan kartu ke mesin EDC, proses pembayaran sebesar:<div class="payment-amount">${money(total)}</div><div class="muted">Pastikan mesin EDC menampilkan transaksi berhasil sebelum menyimpan.</div>`;
            refField.hidden = false;
            $('#referenceLabel').textContent = 'Nomor referensi / approval EDC (opsional)';
            $('#paymentReference').placeholder = 'Nomor approval dari struk EDC';
        }
    }

    function updateChange() {
        const method = $('#method').value;
        if (method === 'Tunai') {
            $('#change').textContent = money(Math.max(0, Number($('#paid').value) - total));
        } else {
            $('#change').textContent = money(total);
        }
    }

    document.querySelectorAll('.product-tile').forEach(b => {
        b.addEventListener('click', () => add(JSON.parse(b.dataset.product)));
    });

    $('#cartItems').addEventListener('click', e => {
        const d = e.target.dataset.dec;
        const i = e.target.dataset.inc;
        if (d) {
            const x = cart.get(d);
            x.qty--;
            if (x.qty <= 0) cart.delete(d);
            calc();
        }
        if (i) {
            const x = cart.get(i);
            if (x.qty >= x.stok) return alert('Jumlah melebihi stok.');
            x.qty++;
            calc();
        }
    });

    $('#discount').addEventListener('input', calc);

    const search = $('#searchProduct');
    search.addEventListener('input', () => {
        const q = search.value.toLowerCase();
        document.querySelectorAll('.product-tile').forEach(b => {
            b.style.display = b.textContent.toLowerCase().includes(q) || b.dataset.product.includes(q) ? '' : 'none';
        });
    });

    search.addEventListener('keydown', e => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const q = search.value.trim().toLowerCase();
            const p = products.find(x => (x.barcode || '').toLowerCase() === q) ||
                products.find(x => x.nama.toLowerCase().includes(q));
            if (p) {
                add(p);
                search.value = '';
                search.dispatchEvent(new Event('input'));
            } else {
                alert('Produk tidak ditemukan.');
            }
        }
    });

    $('#checkoutBtn').addEventListener('click', () => {
        $('#paymentModal').classList.add('open');
        updatePaymentUI();
    });

    $('#closePayment').addEventListener('click', () => $('#paymentModal').classList.remove('open'));
    $('#method').addEventListener('change', updatePaymentUI);
    $('#paid').addEventListener('input', updateChange);

    $('#paymentForm').addEventListener('submit', async e => {
        e.preventDefault();

        const err = $('#paymentError');
        const submit = $('#submitPayment');
        err.style.display = 'none';

        const method = $('#method').value;
        const confirmed = method !== 'Tunai' && $('#paymentConfirmed').checked;

        if (method !== 'Tunai' && !confirmed) {
            err.textContent = 'Centang konfirmasi setelah pembayaran benar-benar berhasil diterima toko.';
            err.style.display = 'block';
            return;
        }

        const payload = {
            csrf: window.CSRF,
            items: [...cart.values()].map(x => ({ id: x.id, qty: x.qty })),
            customer_id: $('#customer').value || null,
            discount: Number($('#discount').value) || 0,
            method,
            paid: method === 'Tunai' ? (Number($('#paid').value) || 0) : total,
            payment_reference: $('#paymentReference').value.trim(),
            payment_confirmed: confirmed
        };

        submit.disabled = true;
        submit.textContent = 'Menyimpan transaksi...';

        try {
            const r = await fetch('api/checkout.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const j = await r.json();
            if (!r.ok || !j.success) throw Error(j.message || 'Transaksi gagal.');
            location.href = 'struk.php?id=' + j.sale_id + '&print=1';
        } catch (ex) {
            err.textContent = ex.message;
            err.style.display = 'block';
            submit.disabled = false;
            submit.textContent = 'Simpan & Cetak Struk';
        }
    });

    calc();
})();
