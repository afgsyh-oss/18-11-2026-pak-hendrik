<?php
require '../config/database.php';
require '../includes/functions.php';
require_staff();
header('Content-Type: application/json; charset=utf-8');

try {
    $data = json_decode(file_get_contents('php://input'), true) ?? [];

    if (!hash_equals($_SESSION['csrf'] ?? '', $data['csrf'] ?? '')) {
        throw new Exception('Token keamanan tidak valid. Muat ulang halaman.');
    }

    $items = $data['items'] ?? [];
    if (!$items) {
        throw new Exception('Keranjang masih kosong.');
    }

    $method = $data['method'] ?? 'Tunai';
    if (!in_array($method, ['Tunai', 'QRIS', 'Transfer', 'Debit'], true)) {
        throw new Exception('Metode pembayaran tidak valid.');
    }

    $reference = trim((string) ($data['payment_reference'] ?? ''));
    $reference = mb_substr($reference, 0, 100);
    $confirmed = !empty($data['payment_confirmed']);

    // Metode non-tunai harus dikonfirmasi kasir setelah pembayaran benar-benar diterima.
    if ($method !== 'Tunai' && !$confirmed) {
        throw new Exception('Konfirmasikan dahulu bahwa pembayaran sudah berhasil diterima toko.');
    }

    $discount = max(0, (float) ($data['discount'] ?? 0));
    $paidInput = max(0, (float) ($data['paid'] ?? 0));

    $pdo->beginTransaction();
    $subtotal = 0;
    $normalized = [];

    $lock = $pdo->prepare("SELECT id,nama,barcode,harga_jual,stok FROM products WHERE id=? FOR UPDATE");

    foreach ($items as $it) {
        $id = (int) ($it['id'] ?? 0);
        $qty = (int) ($it['qty'] ?? 0);

        if ($id < 1 || $qty < 1) {
            throw new Exception('Item transaksi tidak valid.');
        }

        $lock->execute([$id]);
        $p = $lock->fetch();

        if (!$p) {
            throw new Exception('Produk tidak ditemukan.');
        }
        if ((int) $p['stok'] < $qty) {
            throw new Exception('Stok ' . $p['nama'] . ' tidak mencukupi.');
        }

        $line = (float) $p['harga_jual'] * $qty;
        $subtotal += $line;
        $normalized[] = ['p' => $p, 'qty' => $qty, 'line' => $line];
    }

    $discount = min($discount, $subtotal);
    $total = $subtotal - $discount;

    if ($method === 'Tunai') {
        if ($paidInput < $total) {
            throw new Exception('Uang pembayaran kurang dari total belanja.');
        }
        $paid = $paidInput;
        $change = $paid - $total;
    } else {
        // Nilai pembayaran non-tunai dicatat tepat sebesar total transaksi.
        $paid = $total;
        $change = 0;
    }

    $invoice = 'TK-' . date('ymd-His') . '-' . strtoupper(bin2hex(random_bytes(2)));
    $note = $reference !== '' ? 'Referensi ' . $method . ': ' . $reference : null;

    $ins = $pdo->prepare(
        "INSERT INTO sales(invoice,customer_id,user_id,subtotal,diskon,total,metode_bayar,bayar,kembalian,catatan)
         VALUES(?,?,?,?,?,?,?,?,?,?)"
    );

    $customer = empty($data['customer_id']) ? null : (int) $data['customer_id'];
    $ins->execute([
        $invoice,
        $customer,
        $_SESSION['user']['id'],
        $subtotal,
        $discount,
        $total,
        $method,
        $paid,
        $change,
        $note
    ]);

    $saleId = (int) $pdo->lastInsertId();

    $ii = $pdo->prepare(
        "INSERT INTO sale_items(sale_id,product_id,nama_produk,barcode,harga,qty,diskon,total)
         VALUES(?,?,?,?,?,?,0,?)"
    );
    $up = $pdo->prepare("UPDATE products SET stok=stok-? WHERE id=?");

    foreach ($normalized as $n) {
        $p = $n['p'];
        $ii->execute([$saleId, $p['id'], $p['nama'], $p['barcode'], $p['harga_jual'], $n['qty'], $n['line']]);
        $up->execute([$n['qty'], $p['id']]);
    }

    $pdo->commit();

    echo json_encode(['success' => true, 'sale_id' => $saleId, 'invoice' => $invoice]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
