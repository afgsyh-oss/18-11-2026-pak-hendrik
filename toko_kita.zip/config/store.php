<?php
// Isi data pembayaran toko. Ganti dengan informasi resmi milik toko.
return [
    'bank_name' => '',
    'bank_account' => '',
    'bank_holder' => '',
    'qris_image' => '../assets/img/qris.png',
    'store_phone' => '',
];
