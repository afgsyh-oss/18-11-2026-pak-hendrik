<?php
$host = '127.0.0.1';
$db   = 'tokokita_v2';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
 PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
 PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
 PDO::ATTR_EMULATE_PREPARES => false,
];
try { $pdo = new PDO($dsn, $user, $pass, $options); }
catch (PDOException $e) { http_response_code(500); exit('Koneksi database gagal. Periksa config/database.php dan pastikan database tokokita_v2 sudah diimpor. Detail: '.htmlspecialchars($e->getMessage())); }
