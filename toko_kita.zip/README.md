# TOKOKITA

Aplikasi kasir minimarket berbasis PHP Native + MariaDB untuk XAMPP.

## Fitur
- Login admin/kasir.
- Dashboard omzet, transaksi, jumlah produk, stok menipis.
- POS dengan pencarian produk dan barcode scanner USB (scanner mode keyboard + Enter).
- Keranjang, kuantitas, diskon, pembayaran tunai/QRIS/transfer/debit.
- Stok otomatis berkurang ketika transaksi disimpan.
- Struk terpisah dari halaman kasir, lebar konten 72mm untuk printer thermal 80mm, tinggi mengikuti panjang isi.
- CRUD produk, kategori, pelanggan.
- Riwayat transaksi dan laporan penjualan.

## Instalasi Windows XAMPP
1. Ekstrak folder `tokokita_v2` ke `C:\\xampp\\htdocs\\tokokita_v2` (sesuaikan lokasi XAMPP).
2. Jalankan Apache dan MySQL dari XAMPP.
3. Buka `http://localhost/phpmyadmin`.
4. Import `database/tokokita_v2.sql`. File ini membuat database `tokokita_v2` beserta tabel dan data contoh.
5. Periksa `config/database.php`. Default XAMPP: user `root`, password kosong.
6. Buka `http://localhost/tokokita_v2/setup.php` satu kali.
7. Login melalui `http://localhost/tokokita_v2/login.php`.
8. Akun awal: username `admin`, password `admin12345`.
9. Setelah berhasil setup, hapus file `setup.php` dari folder project dan ganti password admin (fitur ubah password belum disertakan pada paket awal).

## Uji kasir
- Login, buka menu Kasir.
- Klik produk atau scan barcode yang terdaftar.
- Klik Proses Pembayaran, isi nominal bayar, simpan.
- Struk akan terbuka dan dialog cetak otomatis muncul.

## Pengaturan cetak Epson TM-T82X
- Pasang driver Epson TM-T82X di Windows dan pilih printer tersebut pada dialog cetak.
- Paper width 80mm; margin None/Minimum; scale 100%; headers and footers browser OFF.
- `assets/css/receipt.css` menggunakan `@page { size: 80mm auto; margin: 0 }`, konten 72mm dan tinggi otomatis.
- Browser/driver dapat berbeda dalam menangani tinggi halaman `auto`. Jika hasil masih terpotong atau keluar halaman kosong, sesuaikan paper size/form pada Printing Preferences driver Epson.
- Paket ini menggunakan dialog cetak browser (`window.print()`), belum direct ESC/POS USB. Untuk cetak senyap/direct print dibutuhkan QZ Tray atau integrasi ESC/POS terpisah.

## Catatan
- Produk contoh dan barcode contoh hanya untuk pengujian.
- Database baru `tokokita_v2` terpisah dari database lama `db_tokokita`; data lama tidak dihapus.
- Sebelum digunakan untuk operasional, tambahkan pengaturan profil toko, penggantian password, hak akses granular, backup rutin, dan uji cetak fisik.
