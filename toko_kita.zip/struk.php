<?php
require 'config/database.php';
require 'includes/functions.php';
require_staff();
$id=(int)($_GET['id']??0);
$s=$pdo->prepare("SELECT s.*,u.nama kasir,c.nama pelanggan FROM sales s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN customers c ON c.id=s.customer_id WHERE s.id=?");
$s->execute([$id]);$sale=$s->fetch();
if(!$sale){http_response_code(404);
exit('Transaksi tidak ditemukan.');
}$s=$pdo->prepare("SELECT * FROM sale_items WHERE sale_id=? ORDER BY id");
$s->execute([$id]);$items=$s->fetchAll();
$auto=isset($_GET['print']);
?>

<!doctype html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Struk <?=e($sale['invoice'])?></title>
        <link rel="stylesheet" href="assets/css/receipt.css">
    </head>
    <body>
        <div class="toolbar no-print">
            <button onclick="window.print()">Cetak Struk</button>
            <a href="transaksi.php">Kembali</a>
        </div>
        <article class="receipt">
            <header class="store">
                <div class="logo">T</div>
                <h1>TOKOKITA</h1>
                <div class="tagline">MINIMARKET</div>
                <p>Jl. Raya Ponorogo<br>Telp. 08xxxxxxxxxx</p>
            </header>
            <div class="dash"></div>
            <section class="meta">
                <div>
                    <span>No. Transaksi</span>
                    <b><?=e($sale['invoice'])?></b>
                </div>
                <div>
                    <span>Tanggal</span>
                    <b><?=date('d/m/Y H:i',strtotime($sale['tanggal']))?></b>
                </div>
                <div>
                    <span>Kasir</span>
                    <b><?=e($sale['kasir']??'-')?></b>
                </div>
                <div>
                    <span>Pelanggan</span>
                    <b><?=e($sale['pelanggan']??'Umum')?></b>
                </div>
            </section>
            <div class="dash"></div>
            <section class="items">
                <?php foreach($items as $it): ?>
                    <div class="item">
                        <b><?=e($it['nama_produk'])?></b>
                        <div class="item-detail">
                            <span><?=number_format($it['qty'])?> x <?=number_format($it['harga'],0,',','.')?></span>
                            <span><?=number_format($it['total'],0,',','.')?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </section>
            <div class="dash"></div>
            <section class="totals">
                <div><span>Subtotal</span><b><?=rupiah($sale['subtotal'])?></b></div>
                <div><span>Diskon</span><b><?=rupiah($sale['diskon'])?></b></div>
                <div class="grand"><span>TOTAL</span><b><?=rupiah($sale['total'])?></b></div>
                <div><span><?=e($sale['metode_bayar'])?></span><b><?=rupiah($sale['bayar'])?></b></div>
                <div><span>Kembalian</span><b><?=rupiah($sale['kembalian'])?></b></div>
            </section>
            <div class="dash"></div>
            <footer class="thanks">
                <b>Terima kasih telah berbelanja!</b>
                <p>Barang yang sudah dibeli tidak dapat ditukar.</p>
                <strong>TOKOKITA</strong>
            </footer>
        </article>

        <?php if($auto): ?>
            <script>window.addEventListener('load',()=>setTimeout(()=>window.print(),350));</script>;
        <?php endif; ?>
    </body>

</html>