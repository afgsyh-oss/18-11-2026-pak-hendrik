<?php
require 'config/database.php';require 'includes/functions.php';require_staff();$pageTitle='Riwayat Transaksi';$from=$_GET['from']??date('Y-m-01');$to=$_GET['to']??date('Y-m-d');$s=$pdo->prepare("SELECT s.*,u.nama kasir FROM sales s LEFT JOIN users u ON u.id=s.user_id WHERE s.order_user_id IS NULL AND DATE(s.tanggal) BETWEEN ? AND ? ORDER BY s.id DESC");$s->execute([$from,$to]);$rows=$s->fetchAll();require 'includes/header.php';?>
<div class="page-head">
    <div>
        <h1>Riwayat Transaksi</h1>
        <p class="sub">Cari dan cetak kembali bukti transaksi.</p>
    </div>
</div>
<div class="card">
    <form class="filters">
        <div class="field">
            <label>Dari tanggal</label>
            <input class="form-control" type="date" name="from" value="<?=e($from)?>">
        </div>
        <div class="field">
            <label>Sampai tanggal</label>
            <input class="form-control" type="date" name="to" value="<?=e($to)?>">
        </div>
        <button class="btn">Tampilkan</button>
    </form>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Invoice</th>
                    <th>Tanggal</th>
                    <th>Kasir</th>
                    <th>Metode</th>
                    <th class="right">Total</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($rows as $r): ?>
                    <tr>
                        <td><b><?=e($r['invoice'])?></b></td>
                        <td><?=e($r['tanggal'])?></td>
                        <td><?=e($r['kasir']??'-')?></td>
                        <td><?=e($r['metode_bayar'])?></td>
                        <td class="right"><?=rupiah($r['total'])?></td>
                        <td><a class="btn btn-light btn-sm" target="_blank" href="struk.php?id=<?=$r['id']?>">Lihat struk</a></td>
                    </tr>
                <?php endforeach; ?>
                <?php if(!$rows): ?>
                    <tr>
                        <td colspan="6" class="empty">Tidak ada transaksi pada periode ini.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require 'includes/footer.php'; ?>