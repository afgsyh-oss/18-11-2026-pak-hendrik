<?php
require 'config/database.php';
require 'includes/functions.php';
require_staff();

$pageTitle = 'Kasir';
$products = $pdo->query("SELECT p.*,c.nama kategori_nama FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.stok>0 ORDER BY p.nama")->fetchAll();
$customers = $pdo->query("SELECT id,nama FROM customers ORDER BY nama")->fetchAll();

/*
 * Isi informasi rekening toko di bawah ini.
 * Untuk QRIS, letakkan gambar QRIS toko di assets/img/qris.png.
 * Jangan memakai QRIS contoh/random untuk menerima pembayaran sungguhan.
 */
$bankName = '';       // Contoh: BRI
$bankAccount = '';    // Nomor rekening toko
$bankHolder = '';     // Nama pemilik rekening
$qrisImage = 'assets/img/qris.png';

require 'includes/header.php';
?>
<div class="page-head">
    <div><h1>Kasir</h1><p class="sub">Pindai barcode atau pilih produk untuk memulai transaksi.</p></div>
    <span class="badge">Scanner USB siap</span>
</div>

<div class="pos-layout">
    <div class="card">
        <div class="field">
            <label>Cari produk / pindai barcode</label>
            <input id="searchProduct" class="form-control" placeholder="Ketik nama atau scan barcode, lalu Enter..." autocomplete="off">
        </div>
        <div id="productGrid" class="product-grid">
            <?php foreach ($products as $p): ?>
                <button class="product-tile" data-product='<?= e(json_encode([
                    'id' => $p['id'],
                    'barcode' => $p['barcode'],
                    'nama' => $p['nama'],
                    'harga' => (float) $p['harga_jual'],
                    'stok' => (int) $p['stok'],
                    'satuan' => $p['satuan']
                ], JSON_HEX_APOS | JSON_HEX_QUOT)) ?>'>
                    <small><?= e($p['kategori_nama'] ?? 'Umum') ?> · Stok <?= (int) $p['stok'] ?></small>
                    <b><?= e($p['nama']) ?></b>
                    <strong><?= rupiah($p['harga_jual']) ?></strong>
                </button>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="card">
        <h2 style="font-size:18px;margin:0 0 15px">Keranjang Belanja</h2>
        <div id="cartItems"><div class="empty">Belum ada produk dipilih.</div></div>

        <div class="field" style="margin-top:15px">
            <label>Pelanggan</label>
            <select id="customer">
                <option value="">Pelanggan umum</option>
                <?php foreach ($customers as $c): ?>
                    <option value="<?= (int) $c['id'] ?>"><?= e($c['nama']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="field">
            <label>Diskon transaksi (Rp)</label>
            <input id="discount" type="number" min="0" value="0" class="form-control">
        </div>

        <div class="total-line"><span>Subtotal</span><b id="subtotal">Rp0</b></div>
        <div class="total-line"><span>Diskon</span><b id="discountLabel">Rp0</b></div>
        <div class="total-line grand"><span>Total</span><span id="grandTotal">Rp0</span></div>
        <button id="checkoutBtn" class="btn" style="width:100%;margin-top:14px" disabled>Proses Pembayaran →</button>
    </div>
</div>

<div class="modal" id="paymentModal">
    <div class="modal-box">
        <div class="modal-head">
            <h2>Pembayaran</h2>
            <button class="close" id="closePayment" type="button">×</button>
        </div>

        <form id="paymentForm">
            <div class="field">
                <label>Metode pembayaran</label>
                <select id="method">
                    <option value="Tunai">Tunai</option>
                    <option value="QRIS">QRIS</option>
                    <option value="Transfer">Transfer</option>
                    <option value="Debit">Debit</option>
                </select>
            </div>

            <div id="paymentGuide" class="payment-guide" aria-live="polite"></div>

            <div class="field" id="paidField">
                <label>Uang diterima (Rp)</label>
                <input id="paid" type="number" min="0" class="form-control" required>
            </div>

            <div class="field" id="referenceField" hidden>
                <label id="referenceLabel" for="paymentReference">Nomor referensi (opsional)</label>
                <input id="paymentReference" type="text" maxlength="100" class="form-control" placeholder="Masukkan nomor referensi transaksi">
            </div>

            <div class="field" id="confirmationField" hidden>
                <label style="display:flex;gap:9px;align-items:flex-start;font-weight:500">
                    <input id="paymentConfirmed" type="checkbox" style="margin-top:3px">
                    <span>Saya sudah memastikan pembayaran berhasil diterima toko.</span>
                </label>
            </div>

            <div class="total-line grand">
                <span id="paymentResultLabel">Kembalian</span>
                <span id="change">Rp0</span>
            </div>

            <button id="submitPayment" class="btn" style="width:100%;margin-top:16px">Simpan & Cetak Struk</button>
            <p id="paymentError" class="alert" style="display:none;margin-top:12px"></p>
        </form>
    </div>
</div>

<style>
.payment-guide{padding:12px 14px;margin:10px 0 14px;border:1px solid #dbe3ec;border-radius:10px;background:#f8fafc;font-size:14px;line-height:1.55}
.payment-guide strong{display:block;margin-bottom:4px}
.payment-guide .payment-amount{font-size:18px;font-weight:700;margin-top:6px}
.payment-guide img{display:block;width:180px;max-width:100%;height:auto;margin:10px auto;border-radius:8px;background:#fff}
.payment-guide .muted{color:#64748b;font-size:12px}
</style>

<script>
window.TOKOKITA_PRODUCTS = <?= json_encode($products, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
window.CSRF = <?= json_encode(csrf_token()) ?>;
window.TOKOKITA_PAYMENT = <?= json_encode([
    'bankName' => $bankName,
    'bankAccount' => $bankAccount,
    'bankHolder' => $bankHolder,
    'qrisImage' => $qrisImage
], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
</script>
<script src="assets/js/pos.js"></script>
<?php require 'includes/footer.php'; ?>
