# TOKOKITA — Update Portal Pelanggan

Update ini menambahkan area belanja mandiri pelanggan ke proyek TOKOKITA PHP Native yang sudah ada.

## Fitur pelanggan
- Registrasi dan login akun pelanggan.
- Katalog dan pencarian produk.
- Keranjang belanja.
- Checkout dengan pilihan ambil sendiri (pickup) atau diantar (delivery).
- Pembayaran manual melalui Transfer atau QRIS.
- Upload bukti pembayaran (JPG, PNG, WEBP, PDF maksimal 3 MB).
- Riwayat pesanan dan status pembayaran.
- Profil pelanggan.

## Alur Admin
- Admin membuka menu **Pesanan Online**.
- Admin memeriksa bukti pembayaran.
- Jika valid, klik **Verifikasi pembayaran**. Stok baru dikurangi setelah verifikasi berhasil.
- Untuk pickup, status berubah menjadi **siap diambil**.
- Untuk delivery, status berubah menjadi **diproses**, lalu Admin dapat menandai **dalam pengiriman**.
- Admin dapat menandai pesanan selesai.
- Jika bukti tidak valid, Admin dapat menolak dan pelanggan dapat mengunggah ulang.

## Cara memasang pada proyek yang sudah ada
1. Backup folder proyek dan database `tokokita_v2` terlebih dahulu.
2. Ekstrak ZIP update ini ke folder proyek TOKOKITA dan izinkan file baru menimpa file yang memang diperbarui.
3. Buka phpMyAdmin, pilih database `tokokita_v2`, tab **Import**, lalu impor `database/migration_customer_portal.sql` satu kali.
4. Jangan impor `database/tokokita_v2.sql` ke database yang sudah berisi data. File itu adalah skema untuk instalasi baru.
5. Isi `config/store.php` dengan nama bank, nomor rekening, dan nama pemilik rekening toko.
6. Jika menggunakan QRIS, buat folder `assets/img` lalu letakkan gambar QRIS resmi toko dengan nama `qris.png`.
7. Pastikan folder `uploads/payment` dapat ditulisi oleh Apache/PHP. File `.htaccess` membatasi akses langsung ke folder tersebut.
8. Buka `login.php`, lalu pilih **Daftar sekarang** untuk membuat akun pelanggan.
9. Login Admin seperti biasa dan buka menu **Pesanan Online** untuk memproses pesanan.

## File penting yang ditambahkan
- `register.php`
- `user/` — halaman pelanggan
- `pesanan.php` — pengelolaan pesanan online untuk Admin
- `bukti_pembayaran.php` — akses bukti pembayaran khusus Admin
- `config/store.php` — informasi pembayaran toko
- `database/migration_customer_portal.sql` — migrasi database untuk proyek yang sudah berjalan

## Catatan keamanan dan operasional
- Pelanggan hanya dapat melihat dan mengelola keranjang, profil, serta pesanan miliknya sendiri.
- Endpoint kasir dan halaman staf tetap dibatasi untuk role Admin/Kasir; menu pesanan online hanya Admin.
- Pembayaran belum terhubung ke payment gateway. Admin wajib memeriksa mutasi/rekening atau aplikasi merchant sebelum memverifikasi bukti.
- Stok dikurangi ketika Admin memverifikasi pembayaran, bukan saat pelanggan baru membuat pesanan.
- Untuk delivery, sistem menyimpan alamat yang dimasukkan saat checkout. Biaya antar belum dihitung otomatis.
- Periksa pengaturan PHP `file_uploads`, `upload_max_filesize` (minimal 3M), dan `post_max_size` (lebih besar dari 3M) jika upload bukti gagal.
- Hapus `setup.php` setelah akun Admin awal dipastikan dapat digunakan.
