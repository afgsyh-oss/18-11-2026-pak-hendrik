<?php
if (session_status() === PHP_SESSION_NONE) session_start();
date_default_timezone_set('Asia/Jakarta');
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function rupiah($n){ return 'Rp'.number_format((float)$n,0,',','.'); }
function redirect($url){ header('Location: '.$url); exit; }
function require_login(){ if(empty($_SESSION['user'])) redirect('login.php'); }
function require_staff(){ require_login(); if(!in_array($_SESSION['user']['role'] ?? '', ['admin','kasir'], true)){ redirect('user/index.php'); } }
function require_admin(){ require_login(); if(($_SESSION['user']['role'] ?? '') !== 'admin'){ http_response_code(403); exit('Akses ditolak. Halaman ini hanya untuk Admin.'); } }
function require_customer(){ if(empty($_SESSION['user'])) redirect('../login.php'); if(($_SESSION['user']['role'] ?? '') !== 'customer'){ redirect('../index.php'); } }
function is_staff(){ return in_array($_SESSION['user']['role'] ?? '', ['admin','kasir'], true); }
function csrf_token(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf(){ if(!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Token keamanan tidak valid. Muat ulang halaman.'); } }
function invoice_code(){ return 'TK-'.date('ymd').'-'.strtoupper(bin2hex(random_bytes(3))); }
